package com.signity.ziprecruiterproj.configs;

public class CommandArguments {
    public static String jobSourceName="";
    public static Integer startDate=0;
    public static Integer endDate=1;
}
